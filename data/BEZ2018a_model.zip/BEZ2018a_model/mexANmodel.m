clear all;
mex -v model_IHC_BEZ2018a.c complex.c  
clear all;
mex -v model_Synapse_BEZ2018a.c complex.c 
